function [fn_val] = fz(z)



%  CASE (1)
   fn_val = 1/z;

%  CASE (2)
%   fn_val = 2*(sqrt(z + 1)-sqrt(z));

%  CASE (3)
%   fn_val = 1/sqrt(z);

%  CASE (4)
%   fn_val = (z^2 -1)/(z^2 + 1)^2;

%  CASE (5)
%    fn_val = 1/(z+1)^2;

%  CASE (6)
%   fn_val = 1/(z^2);

%  CASE (7)
%    fn_val = 1/ (z^2 + 1);

%  CASE (8)
%    fn_val = 1/ (z +0.5);

%  CASE (10)
%    fn_val = exp(-1/z)/sqrt(z);

%  CASE (11)
%    fn_val = exp(-4*sqrt(z));

%  CASE (12)
%    fn_val=atan(1/z);

%  CASE (13)
%    fn_val = 1 / ((z +0.2)^2 + 1);

%  CASE (14)
%fn_val =  1/z^3;

%  CASE (15)
%    fn_val = exp(-2*z)/z;


%  CASE (17)
%    fn_val = 1/ (z^2 + z + 1);

%  CASE (18)
%    fn_val = 3/ (z^2 -9);

%  CASE (19)
%    fn_val = 120/z^6;

%  CASE (20)
%    fn_val = z/ (z^2 + 1)^2;

%  CASE (21)
%    fn_val = 1/ (z + 1) -1/ (z + 1000);


%  CASE (22)
%    fn_val = z / (z^2 + 1);


%  CASE (23)
%    fn_val = 1 / ((z -0.25)^2);

%  CASE (24)
%    fn_val = 1 / (z*sqrt(z));


%  CASE (25)
%    fn_val =1/sqrt(z + 1);

%  CASE (26)
%    fn_val = (z + 2)/(z*sqrt(z));

%  CASE (27)
%    fn_val = 1/ ((z^2 + 1)^2);

%  CASE (28)
%    fn_val =1/(z*(z +1)^2);

%  CASE (29)
%    fn_val = 1/ (z^3 -8);

%  CASE (30)
%    fn_val = log((z^2 + 1/(z^2 +4)));

%  CASE (31)
%    fn_val = log((z + 1)/z);



%  CASE (32)
%    fn_val = log(z)/z;

%  CASE (33)
%    fn_val = (1-exp(-z))/z^2;







end

